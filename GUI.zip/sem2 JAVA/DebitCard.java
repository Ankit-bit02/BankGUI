
/**
 * Write a description of class DebitCard here.
 *
 * @author (22067501_Ankit karna)
 * @version (a version number or a date)
 */
public class DebitCard extends BankCard
{
    // attributes
    private int PINnumber;
    private int withdrawalAmount;
    private String dateOfWithdrawal;
    boolean hasWithdrawan;
    
    // constructor 
    
    public DebitCard(double balanceAmount, int cardId, int bankAccount, String issuerBank, String clientName, int PINnumber){
        super(balanceAmount, cardId, bankAccount, issuerBank);
        super.setclientName(clientName);
        this.PINnumber = PINnumber;
        this.hasWithdrawan = false;
    }
    
    // accessor method
    
    public int getPINnumber(){
        return this.PINnumber;
    }
    
    public int getwithdrawalAmount(){
        return this.withdrawalAmount;
    }
    
    public String getdateOfWithdrawal(){
        return this.dateOfWithdrawal;
    }
    
    public boolean gethasWithdrawan(){
        return this.hasWithdrawan;
    }
    
    // mutator method
    
    public void setwithdrawalAmount(int withdrawalAmount){
        this.withdrawalAmount = withdrawalAmount;
    }
    
    // creating a method
    
    public void withdraw(int withdrawalAmount, String dateOfWithdrawal, int PINnumber){
        if(this.PINnumber == PINnumber){
            if(withdrawalAmount <= super.getbalanceAmount()){
                this.hasWithdrawan = true;
                super.setbalanceAmount(super.getbalanceAmount() - (withdrawalAmount));
                this.withdrawalAmount = withdrawalAmount;
                this.dateOfWithdrawal = dateOfWithdrawal;
                System.out.println("Transaction successful. Your remaining balance is :" + super.getbalanceAmount());
            }
            else{
                System.out.println("Unsufficient balance");
            }
        }
        else{
            System.out.println("Invalid pin number");
        }
    }
    
    // display method
    
    public void display(){
        super.display();
        System.out.println("Your pin number is:" + this.PINnumber);
        if(hasWithdrawan == true){
            System.out.println("Your withdrawal amount is:" + this.withdrawalAmount);
            System.out.println("The date of withdrawal is:" + this.dateOfWithdrawal);
        }
        else{
            System.out.println("No transaction has been carried out. Your balance is:" + super.getbalanceAmount());
        }
    }
}
