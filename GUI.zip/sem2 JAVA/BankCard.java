
/**
 * Write a description of class BankCard here.
 *
 * @author (22067501_Ankit karna)
 * @version (a version number or a date)
 */
public class BankCard
{
    // attributes
    private int cardId;
    private String clientName;
    private String issuerBank;
    private int bankAccount;
    private double balanceAmount;
    
    // constructor
    public BankCard(double balanceAmount, int cardId, int bankAccount, String issuerBank){
        this.balanceAmount = balanceAmount;
        this.cardId = cardId;
        this.bankAccount = bankAccount;
        this.issuerBank = issuerBank;
    }
    
    // accessor method
    
    public int getcardId(){
        return this.cardId;
    }
    
    public String getclientName(){
        return this.clientName;
    }
    
    public String getissuerBank(){
        return this.issuerBank;
    }
    
    public int getbankAccount(){
        return this.bankAccount;
    }
    
    public double getbalanceAmount(){
        return this.balanceAmount;
    }
    
    // mutator method
    
    public void setclientName(String clientName){
        this.clientName = clientName;
    }
    
    public void setbalanceAmount(double balanceAmount){
        this.balanceAmount = balanceAmount;
    }
    
    // display method
    
    public void display(){
        System.out.println("Your Card ID is : " + cardId);
        System.out.println("Client name : " + clientName);
        System.out.println("Issuer bank : " + issuerBank);
        System.out.println("Your Bank account is : " + bankAccount);
        System.out.println("Your Balance amount is : " + balanceAmount);
        
        if(clientName == ""){
            System.out.println("Please insert client name");
            }
            else{
                System.out.println("Enter your name");
            }
    }
}
