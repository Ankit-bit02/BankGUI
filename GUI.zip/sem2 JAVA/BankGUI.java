
/**
 * Write a description of class BankGUI here.
 *
 * @author (22067501_Ankit karna)
 * @version (a version number or a date)
 */
import java.awt.*;
import javax.swing.*;;
import java.awt.event.*;
import java.util.*;

public class BankGUI implements ActionListener
{
    
    //declare all the components here
    
    private JFrame myframe;
    
    
    // debit card declaration
    
    private JLabel debitCardLabel,dbCardIdLabel,dbClientNameLabel,dbIssuerBankLabel,dbBankAccountLabel,dbBalanceAmountLabel,PINnumberLabel,dbCardIdLabel2,withdrawalAmountLabel,dateOfWithdrawalLabel,PINnumberLabel2;
    
    private JTextField dbCardIdField,dbClientNameField,dbIssuerBankField,dbBankAccountField,dbBalanceAmountField,PINnumberField,dbCardIdField2,withdrawalAmountField,PINnumberField2;
    
    private JButton addDebitCardButton,withdrawButton,dbDisplayButton,dbClearButton;
    
    private JComboBox dbDayCombo, dbMonthCombo, dbYearCombo;
    
    
    // credit card declaration
    
    private JLabel creditCardLabel,crCardIdLabel,crClientNameLabel,crIssuerBankLabel,crBankAccountLabel,crBalanceAmountLabel,cvcNumberLabel,interestRateLabel,expirationDateLabel,creditLimitLabel,gracePeriodLabel,crCardIdLabel2;
    
    private JTextField crCardIdField,crClientNameField,crIssuerBankField,crBankAccountField,crBalanceAmountField,cvcNumberField,interestRateField,creditLimitField,gracePeriodField,crCardIdField2;
    
    private JButton addCreditCardButton, creditLimitButton, cancelButton, crDisplayButton, crClearButton;
    
    private JComboBox crDayCombo, crMonthCombo, crYearCombo;
    
    
    // Array list
    
    public ArrayList<BankCard> BankCardArrayList = new ArrayList<BankCard>();
    
    
    public BankGUI(){
    
        //creating a frame

        myframe = new JFrame("Bank GUI");  
        
        
        // GUI for Debit Card.
        
        //for the LABEL.
        
        debitCardLabel = new JLabel("Debit Card");
        dbCardIdLabel = new JLabel("Card ID :");
        dbClientNameLabel = new JLabel("Client Name :");
        dbIssuerBankLabel = new JLabel("Issuer Bank :");
        dbBankAccountLabel = new JLabel("Bank Account :");
        dbBalanceAmountLabel = new JLabel("Balance Amount :");
        PINnumberLabel = new JLabel("PIN number :");
        dbCardIdLabel2 = new JLabel("Card ID :");
        withdrawalAmountLabel = new JLabel("Withdrawal Amount :");
        dateOfWithdrawalLabel = new JLabel("Date of Withdrawal :");
        PINnumberLabel2 = new JLabel("PIN number :");
        
        
        //for the TEXT FIELD
        
        dbCardIdField = new JTextField();
        dbClientNameField = new JTextField();
        dbIssuerBankField = new JTextField();
        dbBankAccountField = new JTextField();
        dbBalanceAmountField = new JTextField();
        PINnumberField = new JTextField();
        dbCardIdField2 = new JTextField();
        withdrawalAmountField = new JTextField();
        PINnumberField2 = new JTextField();
        
        
        // Setting the BOUNDS for Debit Card Label.
        
        debitCardLabel.setBounds(411, 30, 120, 20);
        dbCardIdLabel.setBounds(46, 90, 120, 20);
        dbClientNameLabel.setBounds(46, 115, 77, 20);
        dbIssuerBankLabel.setBounds(46, 137, 74, 20);
        dbBankAccountLabel.setBounds(46, 158, 85, 20);
        dbBalanceAmountLabel.setBounds(46, 180, 99, 20);
        PINnumberLabel.setBounds(46, 205, 75, 20);         
        dbCardIdLabel2.setBounds(518, 90, 48, 20);
        withdrawalAmountLabel.setBounds(518, 123, 121, 20);
        dateOfWithdrawalLabel.setBounds(518, 158, 118, 20);
        PINnumberLabel2.setBounds(518, 188, 75, 20);
        
        
        // Setting BOUNDS for Debit Card TextField.
        
        dbCardIdField.setBounds(186, 90, 120, 20);
        dbClientNameField.setBounds(186, 115, 120, 20);
        dbIssuerBankField.setBounds(186, 139, 120, 20);
        dbBankAccountField.setBounds(186, 162, 120, 20);
        dbBalanceAmountField.setBounds(186, 186, 120, 20);
        PINnumberField.setBounds(186, 208, 120, 20);
        dbCardIdField2.setBounds(652, 90, 120, 20);
        withdrawalAmountField.setBounds(652, 123, 120, 20);
        PINnumberField2.setBounds(652, 190,120, 20);
        
        
        
       // ADDING the Debit Card Label and TextFields on the frame.
       
        myframe.add(debitCardLabel);
        myframe.add(dbCardIdLabel);
        myframe.add(dbClientNameLabel);
        myframe.add(dbIssuerBankLabel);
        myframe.add(dbBankAccountLabel);
        myframe.add(dbBalanceAmountLabel);
        myframe.add(PINnumberLabel);
        myframe.add(dbCardIdLabel2);
        myframe.add(withdrawalAmountLabel);
        myframe.add(dateOfWithdrawalLabel);
        myframe.add(PINnumberLabel2);
        
        myframe.add(dbCardIdField);
        myframe.add(dbClientNameField);
        myframe.add(dbIssuerBankField);
        myframe.add(dbBankAccountField);
        myframe.add(dbBalanceAmountField);
        myframe.add(PINnumberField);
        myframe.add(dbCardIdField2);
        myframe.add(withdrawalAmountField);
        myframe.add(PINnumberField2);
        
        
        // for date of withdrawal combo box.
        
        //array for day.
        
        String[] dbDay = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"};
        dbDayCombo = new JComboBox(dbDay);
        dbDayCombo.setBounds(652, 153, 65, 30);
        myframe.add(dbDayCombo);
        
        //array for month.
    
        String[] dbMonth = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        
        dbMonthCombo = new JComboBox(dbMonth);
        dbMonthCombo.setBounds(730, 153, 80, 30);
        myframe.add(dbMonthCombo);
        
        //array for year.
        
        String[] dbYear = {"1990","1991","1992","1993","1994","1995","1996","1997","1998","1999","2000","2001","2002","2003","2004","2005","2006","2007","2008","2009","2010","2011","2012","2013","2014","2015","2016","2017","2018", "2019","2020","2021","2022","2023","2024"};
        
        dbYearCombo = new JComboBox(dbYear);
        dbYearCombo.setBounds(817, 153, 65, 30);
        myframe.add(dbYearCombo);
        
        
        // Buttons for Adding a Debit Card, Withdraw, Display, and Clear.
        
        addDebitCardButton = new JButton("Add a Debit Card");
        withdrawButton = new JButton("Withdraw");
        dbDisplayButton = new JButton("Display");
        dbClearButton = new JButton("Clear");
        
        addDebitCardButton.setFocusable(false); //removes the border around the text inside the button.
        withdrawButton.setFocusable(false);
        dbDisplayButton.setFocusable(false);
        dbClearButton.setFocusable(false);
        
        
        addDebitCardButton.setBounds(186, 240, 140, 32);
        withdrawButton.setBounds(650, 240, 120, 32);
        dbDisplayButton.setBounds(336, 300, 120, 32);
        dbClearButton.setBounds(500, 300, 120, 32);
        
       
        myframe.add(addDebitCardButton);
        myframe.add(withdrawButton);
        myframe.add(dbDisplayButton);
        myframe.add(dbClearButton);
        
        
        // GUI for Credit Card.
        
        
        // for the LABEL.
        
        creditCardLabel = new JLabel("Credit Card");
        crCardIdLabel = new JLabel("Card ID :");
        crClientNameLabel = new JLabel("Client Name :");
        crIssuerBankLabel = new JLabel("Issuer Bank :");
        crBankAccountLabel = new JLabel("Bank Account :");
        crBalanceAmountLabel = new JLabel("Balance Amount :");
        cvcNumberLabel = new JLabel("CVC Number :");
        interestRateLabel = new JLabel("Interest Rate :");
        expirationDateLabel = new JLabel("Expiration Date :");
        creditLimitLabel = new JLabel("Credit Limit :");
        gracePeriodLabel = new JLabel("Grace Period :");
        crCardIdLabel2 = new JLabel("Card ID :");
        
        
        // for the TEXTFIELD.
        
        crCardIdField = new JTextField();
        crClientNameField = new JTextField();
        crIssuerBankField = new JTextField();
        crBankAccountField = new JTextField();
        crBalanceAmountField = new JTextField();
        cvcNumberField = new JTextField();
        interestRateField = new JTextField();
        creditLimitField = new JTextField();
        gracePeriodField = new JTextField();
        crCardIdField2 = new JTextField();
        
        
        // Setting BOUNDS for Credit Card Label.
        
        creditCardLabel.setBounds(424, 380, 133, 20);
        crCardIdLabel.setBounds(46, 429, 48, 20);
        crClientNameLabel.setBounds(46, 452, 77, 20);
        crIssuerBankLabel.setBounds(46, 475, 74, 20);
        crBankAccountLabel.setBounds(46, 500, 85, 20);
        crBalanceAmountLabel.setBounds(46, 525, 102, 20);
        cvcNumberLabel.setBounds(46, 550, 81, 20);
        interestRateLabel.setBounds(46, 575, 80, 20);
        expirationDateLabel.setBounds(46, 600, 100, 20);
        creditLimitLabel.setBounds(518, 429, 80, 20);
        gracePeriodLabel.setBounds(518, 460, 81, 20);
        crCardIdLabel2.setBounds(518, 550, 60, 20);
        
        
        // Setting BOUNDS for Credit Card TextField.
        
        crCardIdField.setBounds(179, 429, 120, 20);
        crClientNameField.setBounds(179, 452, 120, 20);
        crIssuerBankField.setBounds(179, 475, 120, 20);
        crBankAccountField.setBounds(179, 500, 120, 20);
        crBalanceAmountField.setBounds(179, 525, 120, 20);
        cvcNumberField.setBounds(179, 550, 120, 20);
        interestRateField.setBounds(179, 575, 120, 20);
        creditLimitField.setBounds(652, 429, 120, 20);
        gracePeriodField.setBounds(652, 460, 120, 20);
        crCardIdField2.setBounds(652, 550, 120, 20);
        
        
        // ADDING the Cebit Card Label and TextFields on the frame.
        
        myframe.add(creditCardLabel);
        myframe.add(crCardIdLabel);
        myframe.add(crClientNameLabel);
        myframe.add(crIssuerBankLabel);
        myframe.add(crBankAccountLabel);
        myframe.add(crBalanceAmountLabel);
        myframe.add(cvcNumberLabel);
        myframe.add(interestRateLabel);
        myframe.add(expirationDateLabel);
        myframe.add(creditLimitLabel);
        myframe.add(gracePeriodLabel);
        myframe.add(crCardIdLabel2);
        
        myframe.add(crCardIdField);
        myframe.add(crClientNameField);
        myframe.add(crIssuerBankField);
        myframe.add(crBankAccountField);
        myframe.add(crBalanceAmountField);
        myframe.add(cvcNumberField);
        myframe.add(interestRateField);
        myframe.add(creditLimitField);
        myframe.add(gracePeriodField);
        myframe.add(crCardIdField2);
        
        
        // For Expiration Date Combo Box.
        
        //array for day.
        
        String[] crDay = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"};
        crDayCombo = new JComboBox(crDay);
        crDayCombo.setBounds(179, 600, 65, 30);
        myframe.add(crDayCombo);
        
        //array for month.
    
        String[] crMonth = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        
        crMonthCombo = new JComboBox(crMonth);
        crMonthCombo.setBounds(250, 600, 80, 30);
        myframe.add(crMonthCombo);
        
        //array for year.
        
        String[] crYear = {"1990","1991","1992","1993","1994","1995","1996","1997","1998","1999","2000","2001","2002","2003","2004","2005","2006","2007","2008","2009","2010","2011","2012","2013","2014","2015","2016","2017","2018", "2019","2020","2021","2022","2023","2024"};
        
        crYearCombo = new JComboBox(crYear);
        crYearCombo.setBounds(335, 600, 65, 30);
        myframe.add(crYearCombo);
        

        
        // buttons for Adding a Credit Card, Set Credit Limit, Cancel Credit Card, Display and Clear.
        
        addCreditCardButton = new JButton("Add a Credit Card");
        creditLimitButton = new JButton("Set Credit Limit");
        cancelButton = new JButton("Cancel Credit Card");
        crDisplayButton = new JButton("Display");
        crClearButton = new JButton("Clear");
        
         
        addCreditCardButton.setBounds(178, 650, 140, 32);
        creditLimitButton.setBounds(652, 490, 130, 32);
        cancelButton.setBounds(652, 585, 140, 32);
        crDisplayButton.setBounds(321, 690, 120, 32);
        crClearButton.setBounds(490, 690, 120, 32);
        
        addCreditCardButton.setFocusable(false); // removes the border around the text in the button.
        creditLimitButton.setFocusable(false);
        cancelButton.setFocusable(false);
        crDisplayButton.setFocusable(false);
        crClearButton.setFocusable(false);
        
        myframe.add(addCreditCardButton);
        myframe.add(creditLimitButton);
        myframe.add(cancelButton);
        myframe.add(crDisplayButton);
        myframe.add(crClearButton);
        
        
        // adding the listener to the source. 
        
        addDebitCardButton.addActionListener(this);
        withdrawButton.addActionListener(this);
        dbDisplayButton.addActionListener(this);
        dbClearButton.addActionListener(this);
        
        addCreditCardButton.addActionListener(this); 
        creditLimitButton.addActionListener(this);
        cancelButton.addActionListener(this);
        crDisplayButton.addActionListener(this);
        crClearButton.addActionListener(this);
        
        
        
        
        
        myframe.setSize(920,770); // sets the x and y dimension of the frame.
        myframe.getContentPane().setBackground(Color.LIGHT_GRAY); // sets the background color of the frame.
        myframe.setLayout(null); // sets the layout to null.
        myframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // sets the frame to close when close button is pressed.
        myframe.setVisible(true); // sets the visibility of the frame.
        myframe.setResizable(false); // doesnot let the frame to re-size.
        
    }
    
    
    //Functionality for adding debit card button.
    
    public void actionPerformed(ActionEvent e){
        
        //Implementing Action Listener to the addDebtiCardButton
        
        if(e.getSource() == addDebitCardButton){
            try{
                
                //Retrieving values from text fields.
                
                int cardId = Integer.parseInt(dbCardIdField.getText());
                String clientName = dbClientNameField.getText();
                String issuerBank = dbIssuerBankField.getText();
                int bankAccount = Integer.parseInt(dbBankAccountField.getText());
                double balanceAmount = Double.parseDouble(dbBalanceAmountField.getText());
                int pinNumber = Integer.parseInt(PINnumberField.getText());
                boolean toAdd = true;
                DebitCard dbCard;
                
                if(BankCardArrayList.isEmpty()){
                    
                    dbCard = new DebitCard(balanceAmount, cardId, bankAccount, issuerBank, clientName, pinNumber);
                    BankCardArrayList.add(dbCard);
                    JOptionPane.showMessageDialog(myframe, "Debit card is added successfully.", "Alert", JOptionPane.INFORMATION_MESSAGE);
                    
                }
                else{
                    
                    for(BankCard card : BankCardArrayList){
                        
                        if(card instanceof DebitCard){
                            
                            dbCard = (DebitCard) card;
                            dbCard.display();
                            
                            if(dbCard.getcardId() == cardId){
                                
                                JOptionPane.showMessageDialog(myframe, "Debit card already exists.", "Error!!!", JOptionPane.ERROR_MESSAGE);
                                toAdd = false;
                                break;
                                
                            }
                        }
                        
                        else{
                            
                            JOptionPane.showMessageDialog(myframe, "Card cannot be added!", "Error!!!", JOptionPane.ERROR_MESSAGE);
                            toAdd = false;
                            break;
                            
                        }
                    }
                    
                    if(toAdd == true){
                        
                        dbCard = new DebitCard(balanceAmount, cardId, bankAccount, issuerBank, clientName, pinNumber);
                        BankCardArrayList.add(dbCard);
                        JOptionPane.showMessageDialog(myframe, "Debit card is added successfully.", "Alert", JOptionPane.INFORMATION_MESSAGE);
                        
                    }
                }

            }
            catch(NumberFormatException ex){
                
                JOptionPane.showMessageDialog(myframe, "Invalid !!! \n Please input correct data", "Input Error", JOptionPane.ERROR_MESSAGE);
                
            }
        }
        
        
        //functionality for adding credit card button
        
        if(e.getSource() == addCreditCardButton){
            
            try{
                
                // retrieving values from text fields
                
                int cardId = Integer.parseInt(crCardIdField.getText());
                String clientName = crClientNameField.getText();
                String issuerBank = crIssuerBankField.getText();
                int bankAccount = Integer.parseInt(crBankAccountField.getText());
                double balanceAmount = Double.parseDouble(crBalanceAmountField.getText());
                int CVCnumber = Integer.parseInt(cvcNumberField.getText());
                double interestRate = Double.parseDouble(interestRateField.getText());
                String crDay = (String) crDayCombo.getSelectedItem();
                String crMonth = (String) crMonthCombo.getSelectedItem();
                String crYear = (String) crYearCombo.getSelectedItem();
                String expirationDate = crDay + " " + crMonth + " " + crYear;
                boolean toAdd = true;
                CreditCard crCard;
                
                if(BankCardArrayList.isEmpty()){
                    
                    crCard = new CreditCard(balanceAmount, cardId, bankAccount, issuerBank, clientName, CVCnumber, interestRate, expirationDate);;
                    BankCardArrayList.add(crCard);
                    JOptionPane.showMessageDialog(myframe, "Credit card has been added successfully.", "Alert!!!", JOptionPane.INFORMATION_MESSAGE);
                    
                }
                else{
                    
                    for(BankCard card : BankCardArrayList){
                        
                        if(card instanceof CreditCard){
                            
                            crCard = (CreditCard) card;
                            
                            if(crCard.getcardId() == cardId){
                                
                                JOptionPane.showMessageDialog(myframe, "Credit card already exists.", "Error!!!", JOptionPane.ERROR_MESSAGE);
                                toAdd = false;
                                break;
                                
                            }
                        }
                        
                        else{
                            
                            JOptionPane.showMessageDialog(myframe, "Card not found!!!", "Error!!!", JOptionPane.ERROR_MESSAGE);
                            toAdd = false;
                            break;
                            
                        }
                    }
                    if(toAdd == true){
                        
                        crCard = new CreditCard(balanceAmount, cardId, bankAccount, issuerBank, clientName, CVCnumber, interestRate, expirationDate);  
                        BankCardArrayList.add(crCard);
                        JOptionPane.showMessageDialog(myframe, "Credit card is added successfully.", "Alert", JOptionPane.INFORMATION_MESSAGE);
                        
                    }
                }

            }
            catch(NumberFormatException ex){
                
                JOptionPane.showMessageDialog(myframe, "Invalid !!! \n Please input correct data.", "Input Error", JOptionPane.ERROR_MESSAGE);
                
            }
            
        }
        
        //Implementing Action Listner to the withdrawButton'
        
        if(e.getSource() == withdrawButton){
            try{
                //retrieveing values from text fields
                
                int cardId = Integer.parseInt(dbCardIdField2.getText());
                int withdrawalAmount = Integer.parseInt(withdrawalAmountField.getText());
                int PINnumber = Integer.parseInt(PINnumberField2.getText());
                String dbDay = (String) dbDayCombo.getSelectedItem();
                String dbMonth = (String) dbMonthCombo.getSelectedItem();
                String dbYear = (String) dbYearCombo.getSelectedItem();
                String dateOfWithdrawal = dbDay + " " + dbMonth + " " + dbYear;
                
                if(BankCardArrayList.isEmpty()){
                    
                    JOptionPane.showMessageDialog(myframe, "Card has not been added", "\nPlease add the card first", JOptionPane.ERROR_MESSAGE);
                }
                //if debit card is already present
                else{
                    //loop through the array list
                    
                    for(BankCard card:BankCardArrayList){
                        // is the card debit card or not?
                        
                        if(card instanceof DebitCard){
                            //downcasting
                            
                            DebitCard dbCard = (DebitCard) card;
                            //System.out.println(debitcard.getPINnumber());

                            if(dbCard.getcardId() == cardId && dbCard.getPINnumber() == PINnumber){
                                
                                double initialAmount = dbCard.getbalanceAmount();
                                dbCard.withdraw(withdrawalAmount, dateOfWithdrawal, PINnumber);
                                double finalAmount = dbCard.getbalanceAmount();
                                double remainingAmount = initialAmount - withdrawalAmount;
                                
                                if(withdrawalAmount <= initialAmount){
                                    
                                    JOptionPane.showMessageDialog(myframe, "Money is successfully withdrawn. Your remaining balance is :" + remainingAmount, "No Error", JOptionPane.INFORMATION_MESSAGE);
                                    
                                }
                                
                                else{
                                    
                                    JOptionPane.showMessageDialog(myframe, "Your balance is insufficient", "Error !!!", JOptionPane.INFORMATION_MESSAGE);
                                    
                                }
                            }
                            
                            else{
                                
                                JOptionPane.showMessageDialog(myframe, "Your card Id or PIN number is incorrect. ", "Error !!!", JOptionPane.INFORMATION_MESSAGE);
                                
                            }
                        }
                        
                        else{
                            
                            JOptionPane.showMessageDialog(myframe, "Debit card not found.", "Error!!!", JOptionPane.ERROR_MESSAGE);
                            
                        }
                    }
                }
            }
            
            catch(NumberFormatException ex){
                
                JOptionPane.showMessageDialog(myframe, "Invalid input.", "Please try again !", JOptionPane.INFORMATION_MESSAGE);
                
            }         
        }
        
        
        //functionality for setting credit limit.
        
        if(e.getSource() == creditLimitButton){
            
            try{
                // retrieving values from text fields
                
                int cardId = Integer.parseInt(crCardIdField.getText());
                int newcreditLimit = Integer.parseInt(creditLimitField.getText());
                int newgracePeriod = Integer.parseInt(gracePeriodField.getText());
                
                if(BankCardArrayList.isEmpty()){
                    
                    JOptionPane.showMessageDialog(myframe, "Card has not been added", "\nPlease add the card first", JOptionPane.ERROR_MESSAGE);;
                    
                }
                
                else{
                    
                    //if credit card is already present
                
                    for(BankCard card:BankCardArrayList){
                        
                        //is the card credit card or not??
                        
                        if(card instanceof CreditCard){
                            
                            //downcast
                            
                            CreditCard crCard = (CreditCard) card;
                            
                            if(crCard.getcardId() == cardId){
                                
                                //calling set credit limit method.
                                
                                crCard.setcreditlimit(newcreditLimit, newgracePeriod);
                                
                                if(newcreditLimit <= 2.5 * crCard.getbalanceAmount()){
                                    
                                    JOptionPane.showMessageDialog(myframe, "Credit limit has been set : \n Credit Limit :" + newcreditLimit + "\n Grace Period :" + newgracePeriod, "Alert!!", JOptionPane.INFORMATION_MESSAGE);
                                }
                                
                                else{
                                    
                                    JOptionPane.showMessageDialog(myframe, "Credit limit has not been set", "Error", JOptionPane.ERROR_MESSAGE);
                                    
                                }
                            }
                            
                            else{
                                
                                JOptionPane.showMessageDialog(myframe, "Your card id is incorrect!!!", "Error", JOptionPane.ERROR_MESSAGE);
                                
                            }
                        }
                        else{
                            
                            JOptionPane.showMessageDialog(myframe, "Card not found!!!", "Error", JOptionPane.ERROR_MESSAGE);
                            
                        }
                    }
                }
            }
            catch(NumberFormatException ex){
                
                JOptionPane.showMessageDialog(myframe, "Invalid input!!!, Please check again", "Error!!!", JOptionPane.INFORMATION_MESSAGE);
                
            }
        }
        
        
        //functionality for cancel credit card
        
        if(e.getSource() == cancelButton){
            try{
                // retrieving values from text fields
                
                int cardId = Integer.parseInt(crCardIdField2.getText());
                int newcreditLimit = Integer.parseInt(creditLimitField.getText());
                int newgracePeriod = Integer.parseInt(gracePeriodField.getText());
                int CVCnumber = Integer.parseInt(cvcNumberField.getText());
                
                if(BankCardArrayList.isEmpty()){
                    
                    JOptionPane.showMessageDialog(myframe, "Card not found!!!.", "Error Found!!!", JOptionPane.ERROR_MESSAGE);
                    
                }
                else{
                    
                    for(BankCard card : BankCardArrayList){
                        
                        if(card instanceof CreditCard){
                            
                            //downcast
                            
                            CreditCard crCard = (CreditCard) card;
                            
                            if(crCard.getcardId() == cardId){
                                
                                crCard.cancelCreditCard();
                                creditLimitField.setText("");
                                gracePeriodField.setText("");
                                cvcNumberField.setText("");
                                
                                JOptionPane.showMessageDialog(myframe, "credit card is cancelled successfully.", "No error found.", JOptionPane.INFORMATION_MESSAGE);
                                
                            }
                            
                            else{
                                
                                JOptionPane.showMessageDialog(myframe, "Incorrect Card Id. Credit card is not cancelled.", "Error!!!", JOptionPane.ERROR_MESSAGE);
                                
                            }
                        }
                        
                        else{
                            
                            JOptionPane.showMessageDialog(myframe, "Credit card not found.", "Error !!!", JOptionPane.ERROR_MESSAGE);
                            
                        }
                    }
                }
            }
            
            catch(NumberFormatException ex){
                
                JOptionPane.showMessageDialog(myframe, "Invalid input! Please check again.", "Error!!!", JOptionPane.INFORMATION_MESSAGE);
                
            }
        }
        
        // functionality for display of debit card
        
        if(e.getSource() == dbDisplayButton){
            
                int cardId = Integer.parseInt(dbCardIdField.getText());
                String clientName = dbClientNameField.getText();
                String issuerBank = dbIssuerBankField.getText();
                int bankAccount = Integer.parseInt(dbBankAccountField.getText());
                double balanceAmount = Double.parseDouble(dbBalanceAmountField.getText());
                int pinNumber = Integer.parseInt(PINnumberField.getText());
                int withdrawalAmount = Integer.parseInt(withdrawalAmountField.getText());
                String dbDay = (String) dbDayCombo.getSelectedItem();
                String dbMonth = (String) dbMonthCombo.getSelectedItem();
                String dbYear = (String) dbYearCombo.getSelectedItem();
                String dateOfWithdrawal = dbDay + " " + dbMonth + " " + dbYear;
                
                if(BankCardArrayList.isEmpty()){
                    
                    JOptionPane.showMessageDialog(myframe, "No card found. Nothing to display.", "Error !!!", JOptionPane.ERROR_MESSAGE);
                    
                    
                }
                else{
                    
                    for(BankCard card : BankCardArrayList){
                        
                        if(card instanceof DebitCard){
                            
                            DebitCard dbcard = (DebitCard) card;
                            
                            //calling didsplay method
                            
                            dbcard.display();
                            
                            String msg = "Card Id :" + cardId + "\n Client Name :" + clientName + "\n Issuer Bank :" + issuerBank + "\n Bank Account :" + bankAccount + "\n Balance Amount :" + balanceAmount + "\n Withdrawal Amount :" + withdrawalAmount + "\n PIN number :" + pinNumber + "\n Date of withdrawal :" + dateOfWithdrawal;
                            JOptionPane.showMessageDialog(myframe, msg, "Debit card information dispalyed.", JOptionPane.INFORMATION_MESSAGE);
                            
                            
                        }
                        
                        else{
                            
                            JOptionPane.showMessageDialog(myframe, "Please add the card first.", "Error !!!", JOptionPane.INFORMATION_MESSAGE);
                            
                        }
                    }
                }
        }
        
        // functionality for credit card display button
        
        if(e.getSource() == crDisplayButton){
            
                int cardId = Integer.parseInt(crCardIdField.getText());
                String clientName = crClientNameField.getText();
                String issuerBank = crIssuerBankField.getText();
                int bankAccount = Integer.parseInt(crBankAccountField.getText());
                double balanceAmount = Double.parseDouble(crBalanceAmountField.getText());
                int CVCnumber = Integer.parseInt(cvcNumberField.getText());
                double interestRate = Double.parseDouble(interestRateField.getText());
                String crDay = (String) crDayCombo.getSelectedItem();
                String crMonth = (String) crMonthCombo.getSelectedItem();
                String crYear = (String) crYearCombo.getSelectedItem();
                String expirationDate = crDay + " " + crMonth + " " + crYear;
                int newcreditLimit = Integer.parseInt(creditLimitField.getText());
                int newgracePeriod = Integer.parseInt(gracePeriodField.getText());
                
                if(BankCardArrayList.isEmpty()){
                    
                    JOptionPane.showMessageDialog(myframe, "No card found.Nothing to display.", "Error !!!", JOptionPane.ERROR_MESSAGE);
                    
                }
                
                else{
                    
                    for(BankCard card : BankCardArrayList){
                        
                        if(card instanceof CreditCard){

                            CreditCard crCard = (CreditCard) card;
                            
                            //calling didsplay method
                            
                            crCard.display();
                            
                            String pop_Up1 = "Card Id :" + cardId + "\n Client Name :" + clientName + "\n Issuer Bank :" + issuerBank + "\n Bank Account :" + bankAccount + "\n Balance Amount :" + balanceAmount + "\n CVC number :" + CVCnumber + "\n Interest Rate :" + interestRate + "\n Expiration Date :" + expirationDate + "\n Credit Limit :" + newcreditLimit + "\n Grace Period :" + newgracePeriod ;
                            JOptionPane.showMessageDialog(myframe, pop_Up1, "Credit card information dispalyed.",JOptionPane.INFORMATION_MESSAGE);
                            
                        }
                        
                        else{
                            
                            JOptionPane.showMessageDialog(myframe, "Please add the card first.", "Error !!!", JOptionPane.INFORMATION_MESSAGE);
                            
                        }
                    }
                }
        }
        
        // functionality for debit card clear button.
        
        if(e.getSource() == dbClearButton){
            
            dbCardIdField.setText("");
            dbClientNameField.setText("");
            dbIssuerBankField.setText("");
            dbBankAccountField.setText("");
            dbBalanceAmountField.setText("");
            PINnumberField.setText("");
            dbCardIdField2.setText("");
            withdrawalAmountField.setText("");
            PINnumberField2.setText("");
            
        }
        
        
        // functionality for credit card clear button
        
        if(e.getSource() == crClearButton){
            
            crCardIdField.setText("");
            crClientNameField.setText("");
            crIssuerBankField.setText("");
            crBankAccountField.setText("");
            crBalanceAmountField.setText("");
            cvcNumberField.setText("");
            interestRateField.setText("");
            creditLimitField.setText("");
            gracePeriodField.setText("");
            crCardIdField2.setText("");
            
        }
        
                    
    }
    
    public static void main(String[] args){
        
        //create object of bank GUI
        
        BankGUI obj = new BankGUI();
        
    }
}
