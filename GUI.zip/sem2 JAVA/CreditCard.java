
/**
 * Write a description of class CreditCard here.
 *
 * @author (22067501_Ankit karna)
 * @version (a version number or a date)
 */
public class CreditCard extends BankCard
{
    // attributes
    private int CVCnumber;
    private int creditLimit;
    private double interestRate;
    private String expirationDate;
    private int gracePeriod;
    private boolean isGranted;
    
    // constructor
    
    public CreditCard(double balanceAmount, int cardId, int bankAccount, String issuerBank, String clientName, int CVCnumber, double interestRate, String expirationDate){
        super(balanceAmount, cardId, bankAccount, issuerBank);
        super.setclientName(clientName);
        this.CVCnumber = CVCnumber;
        this.interestRate = interestRate;
        this.expirationDate = expirationDate;
        this.isGranted = false;
    }
    
    // accessor method
    
    public int getCVCnumber(){
        return this.CVCnumber;
    }
    
    public int getcreditLimit(){
        return creditLimit;
    }
    
    public double getinterestRate(){
        return interestRate;
    }
    
    public String getexpirationDate(){
        return expirationDate;
    }
    
    public int getgracePeriod(){
        return gracePeriod;
    }
    
    public boolean getisGranted(){
        return isGranted;
    }
    
    // 
    
    public void setcreditlimit(int newcreditLimit, int newgracePeriod){
        if(creditLimit <= (2.5 * super.getbalanceAmount())){
        this.creditLimit = newcreditLimit;
        this.gracePeriod = newgracePeriod;
        this.isGranted = true;
        System.out.println("Credit is granted." + newcreditLimit);
        }
        else{
            System.out.println("Credit is not granted");
        }
    }
    
    // method
    
    public void cancelCreditCard(){
        this.CVCnumber = 0;
        this.creditLimit = 0;
        this.gracePeriod = 0;
        this.isGranted = false;
    }
    
    // display method
    
    public void display(){
        super.display();
        if(isGranted == true){
            System.out.println("Credit Limit : " + this.creditLimit);
            System.out.println("Grace Period : " + this.gracePeriod);
            System.out.println("Expiration Date : " + this.expirationDate);
        }
        else{
            System.out.println("Credit card is not granted to credit limit and grace period cannot be displayed");
        }
    }
}
